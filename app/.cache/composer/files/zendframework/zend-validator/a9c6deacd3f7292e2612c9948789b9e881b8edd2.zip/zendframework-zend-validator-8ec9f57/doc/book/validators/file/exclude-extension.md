# ExcludeExtension

`Zend\Validator\File\ExcludeExtension` checks the extension of files. It will
assert `false` when a given file matches any of the defined extensions.

This validator is inversely related to the [Extension validator](extension.md);
please refer to that validator for full options and usage examples.
