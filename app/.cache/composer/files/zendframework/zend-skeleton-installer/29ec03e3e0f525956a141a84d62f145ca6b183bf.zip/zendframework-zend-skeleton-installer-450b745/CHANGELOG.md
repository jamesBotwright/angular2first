# Changelog

All notable changes to this project will be documented in this file, in reverse chronological order by release.

## 0.1.3 - 2016-06-27

### Added

- Nothing.

### Deprecated

- Nothing.

### Removed

- Nothing.

### Fixed

- [#4](https://github.com/zendframework/zend-skeleton-installer/pull/4) updates
  the minimum accepted zend-component-installer version to 0.3.

## 0.1.2 - 2016-06-02

### Added

- Nothing.

### Deprecated

- Nothing.

### Removed

- Nothing.

### Fixed

- Allows using zend-component-installer `^0.2` stable versions.

## 0.1.1 - 2016-06-02

### Added

- Nothing.

### Deprecated

- Nothing.

### Removed

- Nothing.

### Fixed

- [#2](https://github.com/zendframework/zend-skeleton-installer/pull/2) updates
  the `Uninstaller` to ensure it also updates the `composer.lock` when complete.

## 0.1.0 - 2016-05-23

First tagged release.

### Added

- Everything.

### Deprecated

- Nothing.

### Removed

- Nothing.

### Fixed

- Nothing.
